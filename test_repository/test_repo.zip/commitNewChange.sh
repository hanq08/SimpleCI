#!/bin/bash

echo "test" >> new_file
git add *
git commit -m "Dummy changes"
